﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;
using System.IO;
using System.Data;

namespace Some_graphs
{
    public partial class FindLinkz : Form
    {
        Form1 F1; //это чтобы ссылаться на форму-родитель
        List<string> par1 = new List<string>(); //это товар
        List<string> par2 = new List<string>(); //его это аналог
        List<int> trusting = new List<int>(); //доверие

        public FindLinkz(Form1 form1)
        {
            F1 = form1; //для связи с основной формой
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) //кнопка "найти связь"
        {
            if (comboBox1.Text != "" | comboBox2.Text != "") //если оба строки не пустые (хоть что-то выбрано)
                if (comboBox1.Text != comboBox2.Text) //и не равны друг другу (товар сам себе - не аналог)
                    MakeEdges(); //представить все записи в БД как вершины графа со списком вершин, в которые можно осуществить переход (вершин-соседей)
                else
                    MessageBox.Show("Неверные входные данные для поиска");
        }

        private void FindLinkz_Load(object sender, EventArgs e)
        {
            DataTable dbTable = new DataTable(); //для адаптера
            DataTable dbTable2 = new DataTable();
            string sqlText = "";
            
            try
            {
                sqlText = "SELECT art1, man1 FROM Autoparts " +
                          "UNION " +
                          "SELECT art2, man2 FROM Autoparts"; //берем все товары - и первую и вторую пару, чтобы юзер мог выбрать любую пару для поиска
                SQLiteDataAdapter adapter = new SQLiteDataAdapter(sqlText, F1.dbConnection); //для передачи из БД в грид
                adapter.Fill(dbTable); //по пути dbConnection берет все и копирует в dbtable

                sqlText = "SELECT art1, man1, art2, man2, trust FROM Autoparts"; //а это для поиска
                SQLiteDataAdapter adapter2 = new SQLiteDataAdapter(sqlText, F1.dbConnection); 
                adapter2.Fill(dbTable2);

                if (dbTable.Rows.Count > 0) //если в БД хоть что-то есть
                {
                    for (int i = 0; i < dbTable.Rows.Count; i++)  //заполняем комбобоксы для юзера
                    {
                        comboBox1.Items.Add(dbTable.Rows[i][0].ToString().Replace(" ", "").ToUpper() + "/" + dbTable.Rows[i][1].ToString().Replace(" ", "").ToUpper());
                        comboBox2.Items.Add(dbTable.Rows[i][0].ToString().Replace(" ", "").ToUpper() + "/" + dbTable.Rows[i][1].ToString().Replace(" ", "").ToUpper());
                    }
                    F1.AddLogLine("Списки заполнены");
                    comboBox1.SelectedIndex = 0; //так лучше
                    comboBox2.SelectedIndex = 0;

                    for (int i = 0; i < dbTable2.Rows.Count; i++) //а это заполнение для поиска, так, чтобы регистр и пробелы были не важны (хотя тут удаляется только 1 пробел, да)
                    { 
                        par1.Add(dbTable2.Rows[i][0].ToString().Replace(" ", "").ToUpper() + "/" + dbTable2.Rows[i][1].ToString().Replace(" ", "").ToUpper());
                        par2.Add(dbTable2.Rows[i][2].ToString().Replace(" ", "").ToUpper() + "/" + dbTable2.Rows[i][3].ToString().Replace(" ", "").ToUpper());
                        trusting.Add(Convert.ToInt32(dbTable2.Rows[i][4])); //уровень доверия
                    }
                }
                else
                    F1.AddLogLine("В БД нет записей"); //если БД пустая
            }
            catch (SQLiteException ex)
            {
                F1.AddLogLine("Поймана ошибка: " + ex.Message);
            }
        }

        public struct Edge //структура для вершины графа
        {
            public string name; //название вершины
            public List<string> peaks; //все соседние вершины
            public List<int> trust; //доверие для каждой из соседних вершин
        }

        private void MakeEdges() //шаг 1. - представить исходные данные в удобном для работы виде
        {
            List<Edge> Edges = new List<Edge>();
            Edges = sup1(Edges, par1);
            Edges = sup1(Edges, par2);
            FindPaths(Edges);
        }

        private List<Edge> sup1(List<Edge> Edges, List<string> par) //чтобы кода было меньше - для составления списка графов с вершинами
        {
            int prov; //условие для цикла
            Edge ed;
            for (int i = 0; i < par.Count; i++) //для каждой пары "название-атрибут"
            {
                prov = 0;
                foreach (Edge e in Edges) //такая вершина уже есть?
                {
                    if (par[i] == e.name)
                        prov = 1; 
                }
                if (prov != 1) //заполняем список смежных вершин
                {
                    ed.name = par[i];
                    ed.peaks = new List<string>(); //если поля не заполнить, то ругается
                    ed.trust = new List<int>();
                    for (int j = 0; j < par.Count; j++)
                    {
                        if (ed.name == par1[j])
                        {
                            ed.peaks.Add(par2[j]);
                            ed.trust.Add(trusting[j]);
                        }
                        if (ed.name == par2[j])
                        {
                            ed.peaks.Add(par1[j]);
                            ed.trust.Add(trusting[j]);
                        }
                    }
                    Edges.Add(ed);
                }
            }
            return Edges;
        }

        private int FindIndex(List<Edge> Edges, string ed) //возвращает индекс из Edges вершины по ее названию
        {
            int index = -1;
            foreach (Edge e in Edges)
            {
                if (e.name == ed)
                    index = Edges.IndexOf(e);
            }
            return index;
        }

        private List<string> FromStackToList(Stack<string> st) //перекидывает все из стека в список, иначе ничего не запоминается
        {
            List<string> li = new List<string>();
            for (int i=0; i<st.Count; i++)
            {
                li.Add(st.ElementAt(i));
            }
            return li;
        }

        public void FindPaths(List<Edge> Edges) //2. перебор маршрутов
        {
            List<List<string>> Paths = new List<List<string>>();
            Stack<String> curPath = new Stack<string>(); //перебор будет через стек
            string nach = comboBox1.Text; //начало
            string kon = comboBox2.Text; //конец
            int depth = (int)numericUpDown1.Value;
            int prov = 0; //для выхода из цикла

            int ind = 0; //индекс текущего элемента из Edges
            int anoth = 0;
            Stack<int> pred = new Stack<int>();//для возвращения при нахождении тупиков
            int SoMany = 0; //и не спрашивайте...            

            int nachind; //возможно уберу - это индекс начального элемента
            Edge nache = new Edge();
            foreach (Edge e in Edges) //ищем его по имени из СВ1
                if (e.name == nach)
                {
                    nachind = Edges.IndexOf(e);
                    nache = e;
                    ind = nachind;
                    break;
                }

            while (prov == 0)
            {
                anoth = 0;
                        if (curPath.Count == 0) //если поиск только начался, первый элемент добавляется так
                            curPath.Push(nache.name);
                        int jope;
                        if (SoMany == 0)
                            jope = 0;
                        else
                            jope = pred.Pop() + 1;
                        for (int i = jope; i < Edges[ind].peaks.Count; i++) //найти след. вершину, которой еще нет в марштуре
                        {
                            if (!curPath.Contains(Edges[ind].peaks[i])) //если этой вершины ЕЩЕ НЕТ в маршруте
                            {
                                curPath.Push(Edges[ind].peaks[i]);// добавить ее в маршрут
                                ind = FindIndex(Edges, Edges[ind].peaks[i]); //теперь будем искать соседей именно для добавленной вершины
                                anoth = 1; //новая вершина найдена
                                pred.Push(i); //это на случай, если след. вершина окажется тупиком
                                SoMany = 0;
                                if (curPath.Count == depth || Edges[FindIndex(Edges, curPath.ElementAt(1))].trust[i] == 0) //elementAt(1) = предыдущий элемент
                                    anoth = 0;
                                break;
                            }
                        }
                        if (anoth == 0) //если новая вершина от прошлой не найдена, а значит это конец маршрута
                            {
                                int ug = 0; //надо!
                                if (curPath.Peek() == kon) //если маршрут кончается не на нашей вершине, значит не запоминаем
                                    Paths.Add(FromStackToList(curPath)); //добавить составленный маршрут в список
                            while (ug == 0)
                                {
                                curPath.Pop();
                                if (curPath.Count == 0)
                                {
                                    prov = 1;
                                    break;
                                }

                                ind = FindIndex(Edges, curPath.Peek()); //откатываемся к предыдущей вершине
                                if (pred.Peek() + 1 < Edges[ind].peaks.Count)
                                    ug = 1;
                                else
                                    pred.Pop();
                                }
                            SoMany = 1; //значит найден тупик (чтоб в след шаге While это знать)
                            }
            }
            F1.AddLogLine("Поиск завершен");
            Resultz rez = new Resultz(F1, this, Paths);
            if (Paths.Count > 0)
            {
                this.Hide();
                rez.ShowDialog();
            }
            else
                MessageBox.Show("Для данной комбинации товаров совпадений не найдено");
        }

    }
}
