﻿using System;
/*using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;*/
using System.Windows.Forms;
using System.Data.SQLite;
using System.IO;
using System.Data;

namespace Some_graphs
{
    public partial class Form1 : Form
    {
        public String dbName = "AutoDB.sqlite"; //имя БД
        public SQLiteConnection dbConnection;
        public SQLiteCommand sqlComm;

        public Form1()
        {
            InitializeComponent();
        }

        public void AddLogLine(string line) //добавить строку в окно лога
        {
            this.textBox1.Text += line + Environment.NewLine; 
        }

        private void Form1_Load(object sender, EventArgs e) //при запуске программы
        {
            AddLogLine("Программа включена");
            sqlComm = new SQLiteCommand();
            dbConnection = new SQLiteConnection();
            dbConCreate();
            ReadDb();
        }

        private void dbConCreate() //создать и/или подключить БД
        {
            if (!File.Exists(dbName)) //если БД с таким именем НЕ существует
            {
                SQLiteConnection.CreateFile(dbName); //создать файл с таким именем в папке с файлом .exe этой программы
                AddLogLine("Создана новая БД с именем " + dbName);
            }

            try
            {
                dbConnection = new SQLiteConnection("Data Source=" + dbName + ";Version=3;"); //это инфа о подключении в БД
                dbConnection.Open(); //пытаемся собственно подключиться к указанной БД
                AddLogLine("БД подключена");
                toolStripStatusLabel2.Text = "подключен"; //так информативнее
                sqlComm.Connection = dbConnection; //чтобы sql команды летели куда надо
                sqlComm.CommandText = "CREATE TABLE IF NOT EXISTS Autoparts (id INTEGER PRIMARY KEY AUTOINCREMENT, art1 TEXT, man1 TEXT, art2 TEXT, man2 TEXT, trust INTEGER)"; //файл БД был создан пустой, поэтому создадим в нем таблицу
                sqlComm.ExecuteNonQuery(); //собственно посылаем запрос в БД на создание новой таблицы (в данном случае ничего не произойдет, если она уже есть)
            }
            catch (SQLiteException ex)
            {
                AddLogLine("Поймана ошибка: " + ex.Message);
            }
        }

        public void ReadDb() //прочитать содержимое БД и вывести его в грид
        {
            DataTable dbTable = new DataTable(); //для адаптера
            string sqlText;

            try
            {
                sqlText = "SELECT art1, man1, art2, man2, trust FROM Autoparts";
                SQLiteDataAdapter adapter = new SQLiteDataAdapter(sqlText, dbConnection); //для передачи из БД в грид
                adapter.Fill(dbTable); //по пути dbConnection берет все и копирует в dbtable

                if (dbTable.Rows.Count > 0) //если в БД хоть что-то есть
                {
                    dataGrid1.Rows.Clear(); //чистим грид, чтобы не добавлялось к тому, что уже там
                    for (int i = 0; i < dbTable.Rows.Count; i++)
                        dataGrid1.Rows.Add(dbTable.Rows[i].ItemArray); //заполняем грид
                    AddLogLine("БД загружена в программу");
                }
                else
                    AddLogLine("В БД нет записей"); //если БД пустая
            }
            catch (SQLiteException ex)
            {
                AddLogLine("Поймана ошибка: " + ex.Message);
            }
        }

        private void выйтиИзПрограммыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddLogLine("Программа закрывается");
            Application.Exit(); //выход из проги
        }

        private void синхронизироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {

            using (SQLiteTransaction transaction = dbConnection.BeginTransaction()) //чтобы сделать много всего за раз
            {
                sqlComm.CommandText = "DELETE FROM Autoparts";
                sqlComm.ExecuteNonQuery();

                for (int i = 0; i < dataGrid1.RowCount - 1; i++)
                {
                    sqlComm.CommandText = "INSERT INTO Autoparts ('art1', 'man1', 'art2', 'man2', 'trust') values ('" +
                                        dataGrid1[0, i].Value + "' , '" +
                                        dataGrid1[1, i].Value + "' , '" +
                                        dataGrid1[2, i].Value + "' , '" +
                                        dataGrid1[3, i].Value + "' , '" +
                                        dataGrid1[4, i].Value + "')";
                    try
                    {
                        sqlComm.ExecuteNonQuery();
                    }
                    catch (SQLiteException ex)
                    {
                        AddLogLine("Поймана ошибка: " + ex.Message + ". Возможно введено недопустимое значение в поле БД");
                    }
                }
                transaction.Commit(); //конец транзакции
            }
        }

        private void прочитатьВсеИзБДToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReadDb();
        }

        private void очиститьТаблицуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGrid1.Rows.Clear(); //чистка всего, что в гриде, кроме заголовка
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FindLinkz FL = new FindLinkz(this);
            FL.ShowDialog(); //открыть форму для поиска
        }
    }
}
