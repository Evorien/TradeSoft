﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Some_graphs
{
    public partial class Resultz : Form
    {
        Form1 F;
        FindLinkz FL;
        List<List<string>> Pathz;
        public Resultz(Form1 form1, FindLinkz FindL, List<List<string>> Pa)
        {
            form1 = form1;
            FL = FindL;
            Pathz = Pa;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void Resultz_Load(object sender, EventArgs e)
        {
            string path;
            for (int i=0; i<Pathz.Count; i++) //цикл по маршрутам
            {
                path = "";
                for (int j=Pathz[i].Count-1; j>=0; j--) //цикл по кол-ву точек маршрута
                {
                    if (j != 0)
                        path += Pathz[i][j] + " -> ";
                    else
                        path += Pathz[i][j];
                }
                dataGridView1.Rows.Add();
                dataGridView1[0, i].Value = "Маршрут №" + i.ToString();
                dataGridView1[1, i].Value = path; 
            }
        }
    }
}
